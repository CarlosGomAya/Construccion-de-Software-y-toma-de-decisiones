const log = console.log;

function money(value) {
    return Number(value || 0).toLocaleString('es-MX');
}

function badgeClass(value) {
    if (value === 'Alto' || value === 'Alerta' || value === 'Rechazado') {
        return 'badge-danger';
    }

    if (value === 'Medio' || value === 'Revision' || value === 'Validacion' || value === 'Pendiente') {
        return 'badge-warn';
    }

    return 'badge-ok';
}

function showMessage(message) {
    const wrapper = document.getElementById('formMessage');

    if (wrapper) {
        wrapper.innerHTML = `<div class="feedback">${message}</div>`;
    }
}

async function getJson(url) {
    const response = await fetch(url);

    if (response.ok) {
        return response.json();
    }

    const errorData = await response.json().catch(function() {
        return {};
    });
    alert(errorData.msg || 'HTTP-Error: ' + response.status);
    return {};
}

async function postJson(url, data) {
    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    if (response.ok) {
        return response.json();
    }

    const errorData = await response.json().catch(function() {
        return {};
    });
    throw new Error(errorData.msg || 'HTTP-Error: ' + response.status);
}

async function cargarClientes() {
    const data = await getJson('/clientes/api/lista');
    const body = document.getElementById('clientesBody');

    if (!body) return;

    body.innerHTML = (data.clientes || []).map(function(cliente) {
        const id = cliente.idCliente || '';
        return `
            <tr>
                <td>${id}</td>
                <td><strong>${cliente.nombre || ''}</strong></td>
                <td style="font-family:monospace;font-size:13px">${cliente.rfc || ''}</td>
                <td>${cliente.tipoPersona || ''}</td>
                <td><span class="badge-soft ${badgeClass(cliente.riesgo)}">${cliente.riesgo || ''}</span></td>
                <td>${cliente.esPep ? '<span class="badge-soft badge-warn">Si</span>' : 'No'}</td>
                <td><span class="badge-soft">${cliente.docs || 'Pendiente'}</span></td>
                <td style="white-space:nowrap">
                    <a href="/clientes/editar?id=${id}" class="btn-small" style="margin-right:4px">Ver expediente</a>
                    <a href="/clientes/documentos?id=${id}" class="btn-small secondary">Documentos</a>
                </td>
            </tr>
        `;
    }).join('') || '<tr><td colspan="8">No hay clientes registrados</td></tr>';
}

async function cargarOperaciones() {
    const data = await getJson('/operaciones/api/lista');
    const body = document.getElementById('operacionesBody');

    if (!body) return;

    body.innerHTML = (data.operaciones || []).map(function(operacion) {
        return `
            <tr>
                <td>${operacion.idOperacion || ''}</td>
                <td>${operacion.cliente || ''}</td>
                <td>${operacion.contrato || ''}</td>
                <td>${operacion.producto || ''}</td>
                <td>${operacion.tipoOperacion || ''}</td>
                <td>$${money(operacion.monto)}</td>
                <td>${operacion.moneda || ''}</td>
                <td>${operacion.fecha || ''}</td>
                <td><span class="badge-soft ${badgeClass(operacion.estatus)}">${operacion.estatus || ''}</span></td>
            </tr>
        `;
    }).join('') || '<tr><td colspan="9">No hay operaciones registradas</td></tr>';
}

async function cargarAlertas() {
    const data = await getJson('/alertas/api/lista');
    const body = document.getElementById('alertasBody');

    if (!body) return;

    body.innerHTML = (data.alertas || []).map(function(alerta) {
        return `
            <tr>
                <td>${alerta.idAlerta || ''}</td>
                <td>${alerta.cliente || ''}</td>
                <td>${alerta.operacion || ''}</td>
                <td>${alerta.regla || ''}</td>
                <td><span class="badge-soft ${badgeClass(alerta.nivel)}">${alerta.nivel || ''}</span></td>
                <td>${alerta.fecha || ''}</td>
                <td>${alerta.responsable || ''}</td>
                <td><button class="btn-small" type="button" onclick="resolverAlerta('${alerta.idAlerta}')">Resolver</button></td>
            </tr>
        `;
    }).join('') || '<tr><td colspan="8">No hay alertas registradas</td></tr>';
}

async function cargarContratos() {
    const data = await getJson('/contratos/api/lista');
    const body = document.getElementById('contratosBody');

    if (!body) return;

    body.innerHTML = (data.contratos || []).map(function(contrato) {
        return `
            <tr>
                <td>${contrato.idContrato || ''}</td>
                <td>${contrato.cliente || ''}</td>
                <td>${contrato.producto || ''}</td>
                <td>${contrato.inicio || ''}</td>
                <td>${contrato.vencimiento || ''}</td>
                <td>$${money(contrato.saldo)}</td>
                <td><span class="badge-soft ${badgeClass(contrato.estatus)}">${contrato.estatus || ''}</span></td>
            </tr>
        `;
    }).join('') || '<tr><td colspan="7">No hay contratos registrados</td></tr>';
}

async function cargarUsuarios() {
    const data = await getJson('/admin/api/lista');
    const body = document.getElementById('usuariosBody');

    if (!body) return;

    body.innerHTML = (data.usuarios || []).map(function(usuario) {
        return `
            <tr>
                <td>${usuario.idUsuario || ''}</td>
                <td>${usuario.nombre || ''}</td>
                <td>${usuario.correo || ''}</td>
                <td>${usuario.rol || ''}</td>
                <td><span class="badge-soft ${badgeClass(usuario.estado)}">${usuario.estado || ''}</span></td>
            </tr>
        `;
    }).join('') || '<tr><td colspan="5">No hay usuarios registrados</td></tr>';
}

async function cargarDashboard() {
    try {
        const data = await getJson('/api/dashboard');

        const totalClientes = document.getElementById('totalClientes');
        const totalOperaciones = document.getElementById('totalOperaciones');
        const totalAlertasPendientes = document.getElementById('totalAlertasPendientes');
        const totalReportesListos = document.getElementById('totalReportesListos');

        if (totalClientes) totalClientes.textContent = data.totalClientes || 0;
        if (totalOperaciones) totalOperaciones.textContent = data.totalOperaciones || 0;
        if (totalAlertasPendientes) totalAlertasPendientes.textContent = data.totalAlertasPendientes || 0;
        if (totalReportesListos) totalReportesListos.textContent = data.totalReportesListos || 0;
    } catch (error) {
        log('Error al cargar dashboard:', error.message);
    }
}

async function cargarReportes() {
    const data = await getJson('/reportes/api/lista');
    const reportes = data.reportes || [];
    const body = document.getElementById('reportesBody');

    if (!body) return;

    body.innerHTML = reportes.map(function(reporte) {
        return `
            <tr>
                <td>${reporte.clave || ''}</td>
                <td>${reporte.nombre || ''}</td>
                <td>${reporte.periodo || ''}</td>
                <td>${reporte.registros || 0}</td>
                <td><span class="badge-soft ${badgeClass(reporte.estatus)}">${reporte.estatus || ''}</span></td>
            </tr>
        `;
    }).join('') || '<tr><td colspan="5">No hay reportes registrados</td></tr>';
}

async function resolverAlerta(idAlerta) {
    try {
        await postJson('/alertas/api/resolver', {
            idAlerta:   idAlerta,
            resolucion: 'Resuelta desde la bandeja'
        });
        cargarAlertas();
    } catch (error) {
        alert('Error al resolver alerta: ' + error.message);
    }
}
