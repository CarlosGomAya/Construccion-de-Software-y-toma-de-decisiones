// Controlador de umbrales y criterios PLD

const modelReglas = require('../models/reglas.model');

// Obtener todas las reglas
module.exports.ObtenerReglas = async (req, res) => {
    res.render('./reglas/lista_reglas');
};

// Vista para agregar regla
module.exports.VistaAgregarRegla = async (req, res) => {
    res.render('./reglas/lista_reglas');
};

// Agregar nueva regla
module.exports.AgregarRegla = async (req, res) => {
    res.redirect('/reglas/lista');
};

// Vista para editar regla
module.exports.VistaEditarRegla = async (req, res) => {
    res.render('./reglas/lista_reglas');
};

// Editar regla existente
module.exports.EditarRegla = async (req, res) => {
    res.redirect('/reglas/lista');
};

// Eliminar regla
module.exports.EliminarRegla = async (req, res) => {
    res.redirect('/reglas/lista');
};
