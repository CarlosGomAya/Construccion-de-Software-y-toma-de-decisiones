// Controller de alertas PLD

const modelAlertas = require('../models/alertas.model');

// Vista lista de alertas
module.exports.ObtenerAlertas = async (req, res) => {
    res.render('./alertas/lista_alertas', {
        mensaje: req.query.mensaje || null
    });
};

// API: devuelve alertas como JSON para el frontend
module.exports.ApiListaAlertas = async (req, res) => {
    try {
        const resultado = await modelAlertas.ObtenerAlertas();
        const alertas = (resultado.alertas || []).map(function(a) {
            return {
                idAlerta:    a.idalerta,
                cliente:     a.idcliente || '',
                operacion:   a.idoperacion || '',
                regla:       a.regla || '',
                nivel:       a.nivel || 'Bajo',
                fecha:       a.fecha || '',
                responsable: a.responsable || '',
                estatus:     a.estatus || 'Pendiente'
            };
        });
        res.json({ alertas: alertas });
    } catch (error) {
        res.status(503).json({ msg: 'Error al obtener alertas', detalle: error.message });
    }
};

// API: resolver una alerta
module.exports.ApiResolverAlerta = async (req, res) => {
    try {
        const { idAlerta, resolucion } = req.body;
        if (!idAlerta) {
            return res.status(400).json({ msg: 'Falta idAlerta' });
        }
        const resultado = await modelAlertas.ResolverAlerta(idAlerta, { resolucion: resolucion || '' });
        res.json({ exito: resultado.exito, msg: 'Alerta resuelta' });
    } catch (error) {
        res.status(503).json({ msg: 'Error al resolver alerta', detalle: error.message });
    }
};

// Vista formulario resolver alerta
module.exports.VistaResolverAlerta = async (req, res) => {
    res.render('./alertas/lista_alertas', {
        mensaje: null
    });
};

// Procesar resolucion de alerta
module.exports.ResolverAlerta = async (req, res) => {
    res.redirect('/alertas/lista');
};
