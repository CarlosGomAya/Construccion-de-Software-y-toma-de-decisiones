// Controlador de historial de acciones y eventos del sistema

const modelHistorial = require('../models/historial.model');

// Obtener historial general
module.exports.ObtenerHistorial = async (req, res) => {
    res.render('./historial/lista_historial');
};

// Historial filtrado por usuario
module.exports.HistorialPorUsuario = async (req, res) => {
    res.render('./historial/lista_historial');
};

// Historial filtrado por tipo de accion
module.exports.HistorialPorAccion = async (req, res) => {
    res.render('./historial/lista_historial');
};

// Detalles de un evento especifico
module.exports.DetalleEvento = async (req, res) => {
    res.render('./historial/lista_historial');
};
